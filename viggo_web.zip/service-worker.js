self.addEventListener('install', e => {
  console.log('Service Worker instalado');
});
